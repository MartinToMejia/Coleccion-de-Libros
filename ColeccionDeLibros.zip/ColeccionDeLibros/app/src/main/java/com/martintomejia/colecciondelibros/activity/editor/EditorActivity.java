package com.martintomejia.colecciondelibros.activity.editor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.martintomejia.colecciondelibros.R;
import com.martintomejia.colecciondelibros.api.ApiClient;
import com.martintomejia.colecciondelibros.api.ApiInterface;
import com.martintomejia.colecciondelibros.model.Book;
import com.thebluealliance.spectrum.SpectrumPalette;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditorActivity extends AppCompatActivity implements EditorView {

    EditText et_name, et_author, et_gender, et_pages;
    ProgressDialog progressDialog;
    SpectrumPalette palette;

    EditorPresenter presenter;

    int color, id;
    String name, author, gender, pages;

    Menu actionMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        et_name = findViewById(R.id.name);
        et_author = findViewById(R.id.author);
        et_gender = findViewById(R.id.gender);
        et_pages = findViewById(R.id.pages);
        palette = findViewById(R.id.palette);

        palette.setOnColorSelectedListener(
                clr -> color = clr
        );

        progressDialog = new ProgressDialog(this );
        progressDialog.setMessage("Por favor, espera...");

        presenter = new EditorPresenter(this);

        Intent intent = getIntent();
        id = intent.getIntExtra("id", 0);
        name = intent.getStringExtra("name");
        author = intent.getStringExtra("author");
        gender = intent.getStringExtra("gender");
        pages = intent.getStringExtra("pages");
        color = intent.getIntExtra("color", 0);

        setDataFromIntentExtra();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_editor, menu);
        actionMenu = menu;

        if (id != 0) {
            actionMenu.findItem(R.id.edit).setVisible(true);
            actionMenu.findItem(R.id.delete).setVisible(true);
            actionMenu.findItem(R.id.save).setVisible(false);
            actionMenu.findItem(R.id.update).setVisible(false);

        } else {
            actionMenu.findItem(R.id.edit).setVisible(false);
            actionMenu.findItem(R.id.delete).setVisible(false);
            actionMenu.findItem(R.id.save).setVisible(true);
            actionMenu.findItem(R.id.update).setVisible(false);
        }

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        String name = et_name.getText().toString().trim();
        String author = et_author.getText().toString().trim();
        String gender = et_gender.getText().toString().trim();
        String pages = et_pages.getText().toString().trim();
        int color = this.color;

        switch (item.getItemId()) {

            case R.id.save:
                //Save
                if (name.isEmpty()) {
                    et_name.setError("Por favor, introduce un nombre");
                } else if (author.isEmpty()) {
                    et_author.setError("Por favor, introduce un autor");
                } else if (gender.isEmpty()) {
                    et_gender.setError("Por favor, introduce un género");
                } else if (pages.isEmpty()) {
                    et_pages.setError("Por favor, introduce el número de páginas");
                } else {
                    presenter.saveBook(name, author, gender, pages, color);
                }
                return true;

            case R.id.edit:
                editMode();
                actionMenu.findItem(R.id.edit).setVisible(false);
                actionMenu.findItem(R.id.delete).setVisible(false);
                actionMenu.findItem(R.id.save).setVisible(false);
                actionMenu.findItem(R.id.update).setVisible(true);

                return true;

            case R.id.update:
                if (name.isEmpty()) {
                    et_name.setError("Por favor, introduce un nombre");
                } else if (author.isEmpty()) {
                    et_author.setError("Por favor, introduce un autor");
                } else if (gender.isEmpty()) {
                    et_gender.setError("Por favor, introduce un género");
                } else if (pages.isEmpty()) {
                    et_pages.setError("Por favor, introduce el número de páginas");
                } else {
                    presenter.updateNote(id, name, author, gender, pages, color);
                }
                return true;

            case R.id.delete:

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
                alertDialog.setTitle("¡Confirmar!");
                alertDialog.setMessage("¿Estás seguro?");
                alertDialog.setNegativeButton("Sí", (dialog, which) -> {
                    dialog.dismiss();
                    presenter.deleteBook(id); });
                alertDialog.setPositiveButton("Cancelar", (dialog, which) ->
                    dialog.dismiss());

                alertDialog.show();

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void showProgress() {
        progressDialog.show();
    }

    @Override
    public void hideProgress() {
        progressDialog.hide();
    }

    @Override
    public void onRequestSuccess(String message) {
        Toast.makeText(EditorActivity.this,
                message,
                Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();
    }

    @Override
    public void onRequestError(String message) {
        Toast.makeText(EditorActivity.this,
                message,
                Toast.LENGTH_SHORT).show();
    }

    private void setDataFromIntentExtra() {

        if (id != 0) {
            et_name.setText(name);
            et_author.setText(author);
            et_gender.setText(gender);
            et_pages.setText(pages);
            palette.setSelectedColor(color);

            getSupportActionBar().setTitle("Libro actualizado");
            readMode();

        } else {

            //Default Color Setup
            palette.setSelectedColor(getResources().getColor(R.color.white));
            color = getResources().getColor(R.color.white);
            editMode();

        }

    }

    private void editMode() {
        et_name.setFocusableInTouchMode(true);
        et_author.setFocusableInTouchMode(true);
        et_gender.setFocusableInTouchMode(true);
        et_pages.setFocusableInTouchMode(true);
        palette.setEnabled(true);
    }

    private void readMode() {
        et_name.setFocusableInTouchMode(false);
        et_author.setFocusableInTouchMode(false);
        et_gender.setFocusableInTouchMode(false);
        et_pages.setFocusableInTouchMode(false);
        et_name.setFocusable(false);
        et_author.setFocusable(false);
        et_gender.setFocusable(false);
        et_pages.setFocusable(false);
        palette.setEnabled(false);
    }
}
