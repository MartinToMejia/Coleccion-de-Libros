package com.martintomejia.colecciondelibros.activity.main;

import com.martintomejia.colecciondelibros.model.Book;

import java.util.List;

public interface MainView {
    void showLoading();
    void hideLoading();
    void onGetResult(List<Book> books);
    void onErrorLoading(String message);
}
