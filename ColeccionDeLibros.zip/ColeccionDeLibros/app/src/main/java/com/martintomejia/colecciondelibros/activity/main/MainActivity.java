package com.martintomejia.colecciondelibros.activity.main;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;

import com.martintomejia.colecciondelibros.R;
import com.martintomejia.colecciondelibros.activity.Loans;
import com.martintomejia.colecciondelibros.activity.MyBooks;
import com.martintomejia.colecciondelibros.activity.Read;
import com.martintomejia.colecciondelibros.activity.Reading;
import com.martintomejia.colecciondelibros.activity.Search;
import com.martintomejia.colecciondelibros.activity.WishList;

public class MainActivity extends AppCompatActivity {

    GridLayout mainGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainGrid = (GridLayout)findViewById(R.id.mainGrid);


        setSingleEvent(mainGrid);
    }

    private void setSingleEvent(GridLayout mainGrid) {

        for(int i = 0; i < mainGrid.getChildCount(); i++) {
            CardView cardView = (CardView)mainGrid.getChildAt(i);
            final int finall = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(finall == 0) {
                        Intent intent = new Intent(MainActivity.this, MyBooks.class);
                        startActivity(intent);
                    }
                    else if(finall == 1) {
                        Intent intent = new Intent(MainActivity.this, WishList.class);
                        startActivity(intent);
                    }
                    else if(finall == 2) {
                        Intent intent = new Intent(MainActivity.this, Loans.class);
                        startActivity(intent);
                    }
                    else if(finall == 3) {
                        Intent intent = new Intent(MainActivity.this, Reading.class);
                        startActivity(intent);
                    }
                    else if(finall == 4) {
                        Intent intent = new Intent(MainActivity.this, Read.class);
                        startActivity(intent);
                    }
                    else if(finall == 5) {
                        Intent intent = new Intent(MainActivity.this, Search.class);
                        startActivity(intent);
                    }
                }
            });
        }
    }
}
