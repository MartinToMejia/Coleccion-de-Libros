package com.martintomejia.colecciondelibros.activity.editor;

import androidx.annotation.NonNull;

import com.martintomejia.colecciondelibros.api.ApiClient;
import com.martintomejia.colecciondelibros.api.ApiInterface;
import com.martintomejia.colecciondelibros.model.Book;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditorPresenter {

    private EditorView view;

    public EditorPresenter(EditorView view) {
        this.view = view;
    }

    void saveBook(final String name, final String author, final String gender, final String pages, final int color) {

            view.showProgress();

            ApiInterface apiInterface = ApiClient.getApiClient()
                    .create(ApiInterface.class);
            Call<Book> call = apiInterface.saveBook(name, author, gender, pages, color);

            call.enqueue(new Callback<Book>() {
                @Override
                public void onResponse(@NonNull Call<Book> call, @NonNull Response<Book> response) {
                    view.hideProgress();

                    if (response.isSuccessful() && response.body() != null) {

                        Boolean success = response.body().getSuccess();

                        if (success) {
                            view.onRequestSuccess(response.body().getMessage());
                        } else {
                            view.onRequestError(response.body().getMessage());
                        }
                    }
                }

                @Override
                public void onFailure(@NonNull Call<Book> call, @NonNull Throwable t) {
                    view.hideProgress();
                    view.onRequestError(t.getLocalizedMessage());
                }
            });
    }

    void updateNote(int id, String name, String author, String gender, String pages, int color) {

        view.showProgress();
        ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);

        Call<Book> call = apiInterface.updateBook(id, name, author, gender, pages, color);
        call.enqueue(new Callback<Book>() {
            @Override
            public void onResponse(@NonNull Call<Book> call, @NonNull Response<Book> response) {
                view.hideProgress();

                if (response.isSuccessful() && response.body() != null) {

                    Boolean success = response.body().getSuccess();

                    if(success) {
                        view.onRequestSuccess(response.body().getMessage());
                    } else {
                        view.onRequestError(response.body().getMessage());
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<Book> call, @NonNull Throwable t) {
                view.hideProgress();
                view.onRequestError(t.getLocalizedMessage());
            }
        });
    }

    void deleteBook(int id) {

        view.showProgress();
        ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<Book> call = apiInterface.deleteBook(id);
        call.enqueue(new Callback<Book>() {
            @Override
            public void onResponse(@NonNull Call<Book> call, @NonNull Response<Book> response) {
                view.hideProgress();

                if (response.isSuccessful() && response.body() != null) {

                    Boolean success = response.body().getSuccess();

                    if (success) {
                        view.onRequestSuccess(response.body().getMessage());
                    } else {
                        view.onRequestError(response.body().getMessage());
                    }

                }
            }

            @Override
            public void onFailure(@NonNull Call<Book> call, @NonNull Throwable t) {
                view.hideProgress();
                view.onRequestError(t.getLocalizedMessage());
            }
        });
    }
}
