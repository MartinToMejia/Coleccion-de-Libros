package com.martintomejia.colecciondelibros.activity.main;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.martintomejia.colecciondelibros.R;
import com.martintomejia.colecciondelibros.model.Book;

import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.RecyclerViewAdapter> {

    private Context context;
    private List<Book> books;
    private ItemClickListener itemClickListener;

    public MainAdapter(Context context, List<Book> books, ItemClickListener itemClickListener) {
        this.context = context;
        this.books = books;
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public RecyclerViewAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_book,
                parent, false);
        return new RecyclerViewAdapter(view, itemClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter holder, int position) {
        Book book = books.get(position);
        holder.tv_name.setText(book.getName());
        holder.tv_author.setText(book.getAuthor());
        holder.tv_gender.setText(book.getGender());
        holder.tv_pages.setText(book.getPages());
        holder.card_item.setCardBackgroundColor(book.getColor());
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    class RecyclerViewAdapter extends RecyclerView.ViewHolder implements  View.OnClickListener {

        TextView tv_name, tv_author, tv_gender, tv_pages;
        CardView card_item;
        ItemClickListener itemClickListener;


        RecyclerViewAdapter(@NonNull View itemView, ItemClickListener itemClickListener) {
            super(itemView);


            tv_name = itemView.findViewById(R.id.name);
            tv_author = itemView.findViewById(R.id.author);
            tv_gender = itemView.findViewById(R.id.gender);
            tv_pages = itemView.findViewById(R.id.pages);
            card_item = itemView.findViewById(R.id.card_item);

            this.itemClickListener = itemClickListener;
            card_item.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            itemClickListener.onItemClick(v, getAdapterPosition());
        }
    }

    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}
